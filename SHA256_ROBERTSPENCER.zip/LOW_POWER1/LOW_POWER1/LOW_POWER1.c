/*
 * LOW_POWER1.c
 *
 * Created: 7/28/2015 9:51:11 PM
 *  Author: coffeedrinker75287
 */ 

#include "sam.h"

/**
 * \brief Application entry point.
 *
 * \return Unused (ANSI-C compatibility).
 */
int main(void)
{
    /* Initialize the SAM system */
    SystemInit();

    while (1) 
    {
        //TODO:: Please write your application code 
    }
}
