/*
 * sha256.c
 *
 * Created: 7/29/2015 1:30:54 AM
 *  Author: coffeedrinker75287
 */ 

#include "sha256.h"


//#define cstMaxBuffer 40
//#define cstByteBlock 64
//#define cstSHA256BLOCK cstByteBlock
//#define cstSHA25632BITWORDS 8


#define cst256h0 0x6a09e667
#define cst256h1 0xbb67ae85
#define cst256h2 0x3c6ef372
#define cst256h3 0xa54ff53a
#define cst256h4 0x510e527f
#define cst256h5 0x9b05688c
#define cst256h6 0x1f83d9ab
#define cst256h7 0x5be0cd19


char dataMessage[cstByteBlock];
unsigned int HSHA[cstSHA25632BITWORDS];


unsigned int KSHA256[cstByteBlock] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2};


// Global Sha Variables
unsigned int aSHA = 0x00;
unsigned int bSHA = 0x00;
unsigned int cSHA = 0x00;
unsigned int dSHA = 0x00;
unsigned int eSHA = 0x00;
unsigned int fSHA = 0x00;
unsigned int gSHA = 0x00;
unsigned int hSHA = 0x00;


// Function Dec
int initialDataMessage(char *);
int initialHSHA(void);
unsigned int SHR_32BIT(int, unsigned int);
unsigned int ROTR_32BIT(int, unsigned int);
unsigned int SIGMA0_32BIT(unsigned int);
unsigned int SIGMA1_32BIT(unsigned int);
unsigned int PSI0_32BIT(unsigned int);
unsigned int PSI1_32BIT(unsigned int);
unsigned int CH_32BIT(unsigned int, unsigned int , unsigned int);
unsigned int MAJ_32BIT(unsigned int, unsigned int, unsigned int);
unsigned int DOSHA256(void);


/************************************************************************/
// int initialHSA(void)
/************************************************************************/
int initialHSHA(void)
{
    HSHA[0] = cst256h0;
	HSHA[1] = cst256h1;
	HSHA[2] = cst256h2;
	HSHA[3] = cst256h3;
	HSHA[4] = cst256h4;
	HSHA[5] = cst256h5;
	HSHA[6] = cst256h6;
	HSHA[7] = cst256h7;
    
    return 0;
}


/************************************************************************/
//int initialDataMessage(char *message)
/************************************************************************/
int initialDataMessage(char *message)
{
// Clear the datamessate
    for (int i = 0; i < cstByteBlock; i++)
        dataMessage[i] = 0x00;

    int i = 0;
    while (message[i] != '\n') {
        dataMessage[i] = message[i];
        i++;
     }

    dataMessage[i] = 0x80;
    dataMessage[cstByteBlock - 1] = 8*i;
    
    return 0;
}







/* ***********************************************************************************
 * 	ROTR_32BIT
 *  rotate right (circular right shift) operation
 *  where x is a w-bit word and n is an integer with 0 <= n < w, is defined by
 *  =(x>>n) | (x<<w-n)
 *  is equivalent to a circular shift (rotation) of x by n positions to the right.
 *
 * return data
 *********************************************************************************** */
unsigned int ROTR_32BIT(int n, unsigned int data)
{
	if (n < 0)
		return -1;
	if (n > 32)
		return -1;
	
	unsigned int returnData = 0;
	returnData = (data >> n)|(data << (32-n));
    
	return returnData;
}





/* ***********************************************************************************
 * 	SHR
 *  SHR Operation operation
 *
 * return data
 *********************************************************************************** */
unsigned int SHR_32BIT(int n, unsigned int data)
{
    if (n < 0)
        return -1;
    if (n > 32)
        return -1;
    
    unsigned int returnData = 0;
    returnData = (data >> n);
    
    return returnData;
}





/* ***********************************************************************************
 *  PSI0_32BIT
 *
 * return data
 *********************************************************************************** */
unsigned int PSI0_32BIT(unsigned int x)
{
	int returnData = 0;
    
	returnData = ROTR_32BIT(7,x) ^ ROTR_32BIT(18,x) ^ SHR_32BIT(3,x);
    
    return returnData;
}





/* ***********************************************************************************
 *  PSI1_32BIT
 *
 * return data
 *********************************************************************************** */
unsigned int PSI1_32BIT(unsigned int x)
{
	int returnData = 0;
    
	returnData = ROTR_32BIT(17,x) ^ ROTR_32BIT(19,x) ^ SHR_32BIT(10,x);
    
    return returnData;
}




/* ***********************************************************************************
 *  SIG0_32BIT
 *
 * return data
 *********************************************************************************** */
unsigned int SIGMA0_32BIT(unsigned int x)
{
	unsigned int returnData = 0;
    
	returnData = ROTR_32BIT(2,x) ^ ROTR_32BIT(13,x) ^ ROTR_32BIT(22,x);
    
    return returnData;
}


/* ***********************************************************************************
 *  SIG1_32BIT
 *
 * return data
 *********************************************************************************** */
unsigned int SIGMA1_32BIT(unsigned int x)
{
	unsigned int returnData = 0;
    
	returnData = ROTR_32BIT(6,x) ^ ROTR_32BIT(11,x) ^ ROTR_32BIT(25,x);
    
    return returnData;
}




/* ***********************************************************************************
 * 	CH_32BIT
 *  CH_32BIT(x,y,z) = (x & y)^( x & z)
 *
 * return data
 *********************************************************************************** */
unsigned int CH_32BIT(unsigned int x, unsigned int y, unsigned int z)
{
	unsigned int returnData = 0;
    
	returnData = (x & y)^((~x) & z);
    
    return returnData;
}





/* ***********************************************************************************
 *  MAJ_32BIT
 *  MAJ_32BIT(x,y,z) = (x & y)^( x & z)^( Y & z)
 *
 * return data
 *********************************************************************************** */
unsigned int MAJ_32BIT(unsigned int x, unsigned int y, unsigned int z)
{
	unsigned int returnData = 0;
    
	returnData = (x & y)^(x & z)^(y & z);
    
    return returnData;
}








/* ***********************************************************************************
* DOSHA256
*********************************************************************************** */

unsigned int DOSHA256(void)
{
    
	unsigned int T1,T2 = 0;
    unsigned int wSHA[cstSHA256BLOCK];
    
    
	
    
    // Init the HSHA
    initialHSHA();
    
    // Start off with only one block
    aSHA = HSHA[0];
    bSHA = HSHA[1];
    cSHA = HSHA[2];
    dSHA = HSHA[3];
    eSHA = HSHA[4];
    fSHA = HSHA[5];
    gSHA = HSHA[6];
    hSHA = HSHA[7];
        
	

    for(int j=0; j < 16; j++)
    {
        wSHA[j] = 0x00;
        wSHA[j] = ((dataMessage[(j*4) + 0]<< 24)&0xFF000000)
                + ((dataMessage[(j*4) + 1]<< 16)&0x00FF0000)
                + ((dataMessage[(j*4) + 2]<< 8)&0x0000FF00)
                + ((dataMessage[(j*4) + 3]<< 0)&0xFF);
    }
    
            for(int j=16; j < cstSHA256BLOCK; j++)
                wSHA[j] = PSI1_32BIT(wSHA[j-2]) + wSHA[j-7] + PSI0_32BIT(wSHA[j-15]) + wSHA[j-16];
                
                T1 = 0;
                T2 = 0;
                for(int j=0; j < cstSHA256BLOCK; j++)
                {
                    T1 = hSHA + SIGMA1_32BIT(eSHA) + CH_32BIT(eSHA, fSHA, gSHA) + KSHA256[j] + wSHA[j];
                    T2 = SIGMA0_32BIT(aSHA) + MAJ_32BIT(aSHA, bSHA, cSHA);
                    hSHA=gSHA;
                    gSHA=fSHA;
                    fSHA=eSHA;
                    eSHA = dSHA + T1; 
                    dSHA=cSHA; 
                    cSHA=bSHA; 
                    bSHA=aSHA; 
                    aSHA=T1 +T2;
                }
	
	
	HSHA[0] = aSHA + HSHA[0];
	HSHA[1] = bSHA + HSHA[1];
	HSHA[2] = cSHA + HSHA[2];
	HSHA[3] = dSHA + HSHA[3];
	HSHA[4] = eSHA + HSHA[4];
	HSHA[5] = fSHA + HSHA[5];
	HSHA[6] = gSHA + HSHA[6];
	HSHA[7] = hSHA + HSHA[7];
	
	
	
	return 0;
}




/************************************************************************/
/* unsigned int * calSHA256(char *);                                    */
/************************************************************************/
unsigned int * calSHA256(char *tempArray)
{
	initialHSHA();
	initialDataMessage(tempArray);
	DOSHA256();
	return HSHA;
}