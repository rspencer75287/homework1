/*
 * sha256.h
 *
 * Created: 7/29/2015 1:23:54 AM
 *  Author: coffeedrinker75287
 */ 


#ifndef SHA256_H_
#define SHA256_H_

#define cstMaxBuffer 40
#define cstByteBlock 64
#define cstSHA256BLOCK cstByteBlock
#define cstSHA25632BITWORDS 8



unsigned int * calSHA256(char *);


#endif /* SHA256_H_ */